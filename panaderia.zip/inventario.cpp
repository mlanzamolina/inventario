#include "inventario.h"
#include <string.h>
using namespace std;
inventario::inventario()
{
    
}